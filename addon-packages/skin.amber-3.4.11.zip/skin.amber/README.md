skin.amber
==========

Amber skin for Kodi

Master branch: Kodi Matrix

Leia branch: Kodi Leia
